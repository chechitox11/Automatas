package tipo_automata;

import java.util.Map;
import java.util.Set;
import java.util.HashSet;

import automata.Automata;

public class AutomataNoDeterminista extends Automata {
    private Map<Integer, Map<Character, Set<Integer>>> transiciones;

    public AutomataNoDeterminista(Set<Integer> estados, Set<Character> alfabeto, Map<Integer, Map<Character, Set<Integer>>> transiciones, int estadoInicial, Set<Integer> estadosFinales) {
        super(estados, alfabeto, estadoInicial, estadosFinales, transiciones);
        this.transiciones = transiciones;

        // Verificar si el autómata es no determinista
        if (!esNoDeterminista()) {
            throw new IllegalArgumentException("El autómata no es no determinista");
        }
    }

    private boolean esNoDeterminista() {
        // Recorrer todas las transiciones
        for (Map.Entry<Integer, Map<Character, Set<Integer>>> transicion : transiciones.entrySet()) {
            for (Map.Entry<Character, Set<Integer>> transicionPorSimbolo : transicion.getValue().entrySet()) {
                // Si alguna transición tiene más de un destino, entonces no es determinista
                if (transicionPorSimbolo.getValue().size() > 1) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Procesa una cadena para determinar si el autómata no determinista puede
     * procesarla desde su estado inicial hasta alcanzar uno de sus estados finales.
     *
     * @param cadena La cadena a procesar.
     * @return true si la cadena es aceptada por el autómata, false de lo contrario.
     * @throws IllegalArgumentException Si el autómata no contiene transiciones definidas para algún estado o símbolo.
     */
    public boolean procesarCadena(String cadena) {
        // Conjunto de estados actuales inicializado con el estado inicial del autómata
        Set<Integer> estadosActuales = new HashSet<>();
        estadosActuales.add(estadoInicial);

        // Iteración sobre cada símbolo de la cadena
        for (char simbolo : cadena.toCharArray()) {
            Set<Integer> nuevosEstados = new HashSet<>();

            // Transiciones regulares para cada estado actual
            for (int estado : estadosActuales) {
                if (transiciones.containsKey(estado) && transiciones.get(estado).containsKey(simbolo)) {
                    // Agregar los estados alcanzables desde el estado actual con el símbolo dado
                    nuevosEstados.addAll(transiciones.get(estado).get(simbolo));
                }
            }

            // Actualizar los estados actuales con los nuevos estados alcanzables
            estadosActuales = nuevosEstados;
        }

        // Verificar si al menos uno de los estados actuales es un estado final
        return estadosActuales.stream().anyMatch(estadosFinales::contains);
    }


    public String getTipo() {
        return "No Determinista";
    }
}



